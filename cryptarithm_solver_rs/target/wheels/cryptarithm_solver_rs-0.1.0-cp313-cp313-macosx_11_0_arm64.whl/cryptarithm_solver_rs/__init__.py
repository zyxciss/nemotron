from .cryptarithm_solver_rs import *

__doc__ = cryptarithm_solver_rs.__doc__
if hasattr(cryptarithm_solver_rs, "__all__"):
    __all__ = cryptarithm_solver_rs.__all__